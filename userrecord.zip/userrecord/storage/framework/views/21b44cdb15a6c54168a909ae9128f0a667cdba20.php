
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','User'); ?>
<?php $__env->startSection('keyword','User'); ?>
<?php $__env->startSection('description','User'); ?>
<div class="row">
<div class="col-lg-12 margin-tb">
<div class="pull-left">
<h2>User</h2>
</div>
<div class="pull-right mb-2">
<a class="btn btn-success" href="<?php echo e(url('users/create')); ?>"> Create User</a>
</div>
</div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<table class="table table-bordered">
<tr>

<th>First Name</th>
<th>Aast Name</th>
<th>Email</th>
<th>Country</th>
<th width="280px">Action</th>
</tr>
<?php $__currentLoopData = $userlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($value->firstname); ?></td>
<td><?php echo e($value->lastname); ?></td>
<td><?php echo e($value->email); ?></td>
<td><?php echo e($countryList[$value->country]); ?></td>
<td>
<a  class="btn btn-primary" href="<?php echo e(url('users/edit/'.$value->id)); ?>">Edit</a>
|
<a  class="btn btn-danger" href="<?php echo e(url('users/delete/'.$value->id)); ?>" onclick="return confirm('Are you sure?');">Delete</a>
    
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $userlists->links(); ?>

<style>
    .hidden{
        display:none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\development\htdocs\userrecord\resources\views/users/index.blade.php ENDPATH**/ ?>