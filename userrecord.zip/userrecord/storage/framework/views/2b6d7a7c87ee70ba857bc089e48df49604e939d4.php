<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
<meta name="keywords" content="<?php echo $__env->yieldContent('keyword'); ?>">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
</head>
<body>
<div class="container mt-2">
	<?php if ($__env->exists('users.header')) echo $__env->make('users.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	 <?php echo $__env->yieldContent('content'); ?>
	<?php if ($__env->exists('users.footer')) echo $__env->make('users.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</body>
</html><?php /**PATH D:\development\htdocs\userrecord\resources\views/users/userlayout.blade.php ENDPATH**/ ?>